.. tud_lbm documentation master file, created by
   sphinx-quickstart on Wed May  5 22:45:36 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tud_lbm's documentation!
==========================================================

.. toctree::
  :maxdepth: 2
  :caption: Design & Architecture:

  architecture
  lattice
  operators
  adapters

.. toctree::
  :maxdepth: 2
  :caption: API Reference:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
